package id.gampork.finance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import id.gampork.finance.data.FinanceDatabase
import id.gampork.finance.data.FinanceTransaction
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Forest = Color(0xFF0B1118)
private val Panel = Color(0xFF151E28)
private val Panel2 = Color(0xFF1B2633)
private val Gold = Color(0xFFE7B54B)
private val Cream = Color(0xFFF1F4F8)
private val Muted = Color(0xFF9AA8BA)
private val Green = Color(0xFF45C995)
private val Red = Color(0xFFEF747A)
private val Border = Color(0xFF2A3645)

private enum class Page(val label: String) {
    DASHBOARD("Dashboard"), SALES("Penjualan"), EXPENSES("Pengeluaran"),
    REPORTS("Laporan"), MENUS("Menu & Harga"), EXPENSE_TYPES("Jenis Pengeluaran"), SETTINGS("Pengaturan")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = FinanceDatabase.get(applicationContext).transactionDao()
        setContent {
            val vm: FinanceViewModel = viewModel(factory = FinanceViewModel.Factory(dao))
            GamporkApp(vm)
        }
    }
}

class FinanceViewModel(private val dao: id.gampork.finance.data.TransactionDao) : ViewModel() {
    val transactions = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val income = dao.observeIncome().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val expense = dao.observeExpense().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    fun add(title: String, amount: Long, type: String, category: String, note: String) {
        viewModelScope.launch {
            dao.insert(FinanceTransaction(title = title.trim(), amount = amount, type = type, category = category, note = note.trim()))
        }
    }
    class Factory(private val dao: id.gampork.finance.data.TransactionDao) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = FinanceViewModel(dao) as T
    }
}

@Composable
fun GamporkApp(vm: FinanceViewModel) {
    val transactions by vm.transactions.collectAsStateWithLifecycle()
    val income by vm.income.collectAsStateWithLifecycle()
    val expense by vm.expense.collectAsStateWithLifecycle()
    var page by remember { mutableStateOf(Page.DASHBOARD) }
    var showAdd by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf("INCOME") }
    var darkMode by remember { mutableStateOf(true) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Green, background = Forest, surface = Panel,
        onPrimary = Forest, onBackground = Cream, onSurface = Cream
    )) {
        val bg = if (darkMode) Forest else Color(0xFFF3F5F8)
        val card = if (darkMode) Panel else Color.White
        val fg = if (darkMode) Cream else Color(0xFF17212B)
        Scaffold(
            containerColor = bg,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(if (darkMode) Forest else Color.White)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).background(Gold, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                        Text("GP", color = Forest, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("KELOLA KEUANGAN", color = fg, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                        Text("GAMPORK", color = fg, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Dashboard usaha • Makanan & Minuman", color = Muted, fontSize = 11.sp)
                    }
                    TextButton(onClick = { darkMode = !darkMode }) {
                        Text(if (darkMode) "☼ Mode terang" else "☾ Mode gelap", color = Gold, fontSize = 11.sp)
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = if (darkMode) Color(0xFF111923) else Color.White) {
                    val visible = listOf(Page.DASHBOARD, Page.SALES, Page.EXPENSES, Page.REPORTS, Page.MENUS, Page.EXPENSE_TYPES, Page.SETTINGS)
                    visible.forEach { p ->
                        val icon = when (p) {
                            Page.DASHBOARD -> Icons.Default.GridView
                            Page.SALES -> Icons.Default.TrendingUp
                            Page.EXPENSES -> Icons.Default.TrendingDown
                            Page.REPORTS -> Icons.Default.ReceiptLong
                            Page.MENUS -> Icons.Default.MenuBook
                            Page.EXPENSE_TYPES -> Icons.Default.Add
                            Page.SETTINGS -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = page == p, onClick = { page = p },
                            icon = { Icon(icon, contentDescription = p.label) },
                            label = { Text(p.label, fontSize = 9.sp, maxLines = 2) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted)
                        )
                    }
                }
            },
            floatingActionButton = {
                if (page == Page.SALES || page == Page.EXPENSES || page == Page.DASHBOARD) {
                    FloatingActionButton(
                        onClick = { addType = if (page == Page.EXPENSES) "EXPENSE" else "INCOME"; showAdd = true },
                        containerColor = Gold, contentColor = Forest
                    ) { Icon(Icons.Default.Add, contentDescription = "Tambah transaksi") }
                }
            }
        ) { padding ->
            when (page) {
                Page.DASHBOARD -> DashboardScreen(Modifier.padding(padding), income, expense, transactions, card, fg) { addType = "INCOME"; showAdd = true }
                Page.SALES -> TransactionPage(Modifier.padding(padding), "Penjualan", "Catat pemasukan berdasarkan menu makanan atau minuman.", transactions.filter { it.type == "INCOME" }, card, fg, true) { addType = "INCOME"; showAdd = true }
                Page.EXPENSES -> TransactionPage(Modifier.padding(padding), "Pengeluaran", "Catat pembelian bahan dagangan dan biaya lainnya.", transactions.filter { it.type == "EXPENSE" }, card, fg, false) { addType = "EXPENSE"; showAdd = true }
                Page.REPORTS -> ReportsScreen(Modifier.padding(padding), income, expense, transactions, card, fg)
                Page.MENUS -> CatalogScreen(Modifier.padding(padding), "Menu & Harga", "Daftar makanan dan minuman", listOf("Sate Babi", "Lontong + Sate", "Balung Babi", "Nasi", "Es Teh", "Teh Hangat", "Aqua Gelas"), card, fg)
                Page.EXPENSE_TYPES -> CatalogScreen(Modifier.padding(padding), "Daftar Pengeluaran", "Jenis pengeluaran dan harga acuan", listOf("Daging Babi 1 Kg", "Bumbu Ayam Betutu", "Lontong", "Tusuk sate", "Arang Tempurung Kelapa", "Gas", "Aqua Gelas"), card, fg)
                Page.SETTINGS -> SettingsScreen(Modifier.padding(padding), card, fg, darkMode, { darkMode = it })
            }
        }
        if (showAdd) AddTransactionDialog(
            initialType = addType,
            onDismiss = { showAdd = false },
            onSave = { title, amount, type, category, note -> vm.add(title, amount, type, category, note); showAdd = false }
        )
    }
}

@Composable
private fun PageHeading(title: String, subtitle: String, fg: Color, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title, color = fg, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
        if (action != null && onAction != null) {
            Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Forest), shape = RoundedCornerShape(14.dp)) {
                Text(action, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun DashboardScreen(modifier: Modifier, income: Long, expense: Long, transactions: List<FinanceTransaction>, card: Color, fg: Color, onSale: () -> Unit) {
    val balance = income - expense
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val todayIncome = transactions.filter { it.type == "INCOME" && dateKey(it.createdAt) == today }.sumOf { it.amount }
    val todayExpense = transactions.filter { it.type == "EXPENSE" && dateKey(it.createdAt) == today }.sumOf { it.amount }
    val last7 = (0..6).map { offset ->
        val cal = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -offset) }
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val label = SimpleDateFormat("EEE, dd", Locale("id", "ID")).format(cal.time)
        label to transactions.filter { it.type == "INCOME" && dateKey(it.createdAt) == key }.sumOf { it.amount }
    }.reversed()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Dashboard", "Ringkasan kondisi keuangan usaha hari ini.", fg, "+ Penjualan", onSale)
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6B5A38))) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("SALDO SAAT INI", color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(rupiah(balance), color = Green, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("Akumulasi seluruh pemasukan dikurangi pengeluaran aktif", color = Muted, fontSize = 12.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Total Pemasukan", income, Green, card, Modifier.weight(1f))
            MetricCard("Total Pengeluaran", expense, Red, card, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("Pemasukan Hari Ini", todayIncome, fg, card, Modifier.weight(1f))
            MetricCard("Pengeluaran Hari Ini", todayExpense, fg, card, Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Penjualan 7 Hari Terakhir", color = fg, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("Omzet harian", color = Muted, fontSize = 11.sp)
                }
                val max = (last7.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
                last7.forEach { (label, amount) ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.width(62.dp))
                        Box(Modifier.weight(1f).height(9.dp).background(Panel2, RoundedCornerShape(10.dp))) {
                            Box(Modifier.fillMaxWidth(amount.toFloat() / max).fillMaxHeight().background(Gold, RoundedCornerShape(10.dp)))
                        }
                        Text(rupiah(amount), color = fg, fontSize = 11.sp, modifier = Modifier.width(84.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, amount: Long, accent: Color, card: Color, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(rupiah(amount), color = accent, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Text("Seluruh transaksi aktif", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun TransactionPage(modifier: Modifier, title: String, subtitle: String, transactions: List<FinanceTransaction>, card: Color, fg: Color, isSales: Boolean, onAdd: () -> Unit) {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Semua kategori") }
    var status by remember { mutableStateOf("Semua") }
    val categories = listOf("Semua kategori") + transactions.map { it.category }.distinct()
    val filtered = transactions.filter {
        (it.title.contains(search, true) || it.note.contains(search, true) || it.category.contains(search, true)) &&
            (category == "Semua kategori" || it.category == category)
    }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        PageHeading(title, subtitle, fg, if (isSales) "+ Penjualan" else "+ Pengeluaran", onAdd)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (isSales) "Cari menu atau catatan" else "Cari bahan, kategori, keterangan") }, singleLine = true)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) }
                    }
                }
                Text("Daftar transaksi • ${filtered.size} catatan", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ReceiptLong, null, tint = Gold, modifier = Modifier.size(42.dp))
                    Text("Belum ada transaksi", color = fg, fontWeight = FontWeight.Bold)
                    Text("Gunakan tombol tambah untuk mulai mencatat.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(filtered, key = { it.id }) { tx ->
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(tx.title, color = fg, fontWeight = FontWeight.SemiBold)
                                Text("${tx.category} • ${dateText(tx.createdAt)}", color = Muted, fontSize = 11.sp)
                                if (tx.note.isNotBlank()) Text(tx.note, color = Muted, fontSize = 12.sp)
                            }
                            Text(rupiah(tx.amount), color = if (isSales) Green else Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportsScreen(modifier: Modifier, income: Long, expense: Long, transactions: List<FinanceTransaction>, card: Color, fg: Color) {
    var period by remember { mutableStateOf("Harian") }
    val now = Date()
    val todayKey = dateKey(now.time)
    val filtered = transactions.filter { tx ->
        val date = Date(tx.createdAt)
        when (period) {
            "Harian" -> dateKey(tx.createdAt) == todayKey
            "Mingguan" -> (now.time - tx.createdAt) <= 7L * 24 * 60 * 60 * 1000
            "Bulanan" -> SimpleDateFormat("yyyy-MM", Locale.US).format(date) == SimpleDateFormat("yyyy-MM", Locale.US).format(now)
            else -> true
        }
    }
    val inc = filtered.filter { it.type == "INCOME" }.sumOf { it.amount }
    val exp = filtered.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Laporan Transaksi", "Lihat hasil harian, mingguan, atau bulanan.", fg)
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Periode laporan", color = Muted, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Harian", "Mingguan", "Bulanan", "Semua").forEach { p ->
                        FilterChip(selected = period == p, onClick = { period = p }, label = { Text(p, fontSize = 11.sp) })
                    }
                }
                ReportMetric("Pemasukan", inc, Green, card)
                ReportMetric("Pengeluaran", exp, Red, card)
                ReportMetric("Selisih", inc - exp, fg, card)
                Text("${filtered.size} transaksi dalam periode terpilih", color = Muted, fontSize = 12.sp)
            }
        }
        Text("Rincian transaksi", color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        filtered.sortedByDescending { it.createdAt }.forEach { tx ->
            Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx.title, color = fg, fontWeight = FontWeight.Medium)
                        Text(dateText(tx.createdAt), color = Muted, fontSize = 11.sp)
                    }
                    Text(rupiah(tx.amount), color = if (tx.type == "INCOME") Green else Red, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ReportMetric(title: String, amount: Long, accent: Color, card: Color) {
    Row(Modifier.fillMaxWidth().background(card, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Muted, modifier = Modifier.weight(1f))
        Text(rupiah(amount), color = accent, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun CatalogScreen(modifier: Modifier, title: String, subtitle: String, items: List<String>, card: Color, fg: Color) {
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var newItem by remember { mutableStateOf("") }
    val extraItems = remember { mutableStateListOf<String>() }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        PageHeading(title, subtitle, fg, if (title == "Menu & Harga") "+ Tambah menu" else "+ Jenis biaya") { showAdd = true }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cari nama") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border)) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text(if (title == "Menu & Harga") "Daftar Makanan & Minuman" else "Jenis Pengeluaran dan Harga Acuan", color = fg, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(10.dp))
                (items + extraItems).filter { it.contains(query, true) }.forEachIndexed { index, item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (title == "Menu & Harga") if (item in listOf("Es Teh", "Teh Hangat", "Aqua Gelas")) "Minuman" else "Makanan" else "Referensi biaya", color = Muted, fontSize = 11.sp)
                            Text(item, color = fg, fontWeight = FontWeight.Medium)
                        }
                        if (title != "Menu & Harga") Text("Atur saat transaksi", color = Gold, fontSize = 11.sp)
                    }
                    if (index < items.size + extraItems.size - 1) HorizontalDivider(color = Border)
                }
            }
        }
        if (showAdd) AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(if (title == "Menu & Harga") "Tambah menu" else "Tambah jenis pengeluaran") },
            text = { OutlinedTextField(newItem, { newItem = it }, label = { Text("Nama") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (newItem.isNotBlank()) extraItems.add(newItem.trim()); newItem = ""; showAdd = false }) { Text("Tambah") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Batal") } }
        )
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier, card: Color, fg: Color, darkMode: Boolean, onDarkMode: (Boolean) -> Unit) {
    var businessName by remember { mutableStateOf("Angkringan Gampork") }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageHeading("Pengaturan", "Kelola preferensi aplikasi dan data usaha.", fg)
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Profil usaha", color = fg, fontWeight = FontWeight.Bold)
                OutlinedTextField(businessName, { businessName = it }, label = { Text("Nama usaha") }, modifier = Modifier.fillMaxWidth())
                HorizontalDivider(color = Border)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Mode gelap", color = fg, fontWeight = FontWeight.Medium)
                        Text("Tampilan gelap elegan", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = darkMode, onCheckedChange = onDarkMode)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Penyimpanan data", color = fg, fontWeight = FontWeight.Bold)
                Text("Data transaksi disimpan di perangkat (offline). Sinkronisasi cloud, backup otomatis, dan pemulihan data belum diaktifkan pada versi awal.", color = Muted, fontSize = 13.sp)
                Text("Versi aplikasi 1.0.0 • Angkringan Gampork", color = Gold, fontSize = 12.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(initialType: String, onDismiss: () -> Unit, onSave: (String, Long, String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(initialType) }
    var category by remember { mutableStateOf(if (initialType == "EXPENSE") "Bahan baku" else "Makanan") }
    var note by remember { mutableStateOf("") }
    val categories = when (type) {
        "EXPENSE" -> listOf("Bahan baku", "Operasional", "Gaji", "Sewa", "Listrik/Air", "Gas", "Kemasan", "Lainnya")
        "CAPITAL" -> listOf("Modal tambahan")
        "WITHDRAWAL" -> listOf("Prive / uang pribadi")
        else -> listOf("Makanan", "Minuman", "Penjualan lain")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == "EXPENSE") "Tambah pengeluaran" else "Tambah penjualan", color = Forest, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(if (type == "EXPENSE") "Nama bahan / biaya" else "Nama menu / transaksi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amountText, { amountText = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Jenis transaksi", color = Muted, fontWeight = FontWeight.SemiBold)
                listOf("INCOME" to "Pemasukan / penjualan", "EXPENSE" to "Pengeluaran", "CAPITAL" to "Modal tambahan", "WITHDRAWAL" to "Penarikan pribadi").forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = type == value, onClick = { type = value; category = when(value) { "EXPENSE" -> "Bahan baku"; "CAPITAL" -> "Modal tambahan"; "WITHDRAWAL" -> "Prive / uang pribadi"; else -> "Makanan" } })
                        Text(label, fontSize = 12.sp, color = Forest)
                    }
                }
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) }
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amount = amountText.toLongOrNull() ?: 0L
                if (title.isNotBlank() && amount > 0) onSave(title, amount, type, category, note)
            }) { Text("Simpan", color = Forest) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Forest) } }
    )
}

private fun rupiah(value: Long): String {
    val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
    formatter.maximumFractionDigits = 0
    return "Rp " + formatter.format(value)
}
private fun dateKey(timestamp: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(timestamp))
private fun dateText(timestamp: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(timestamp))
