# Angkringan Gampork — Android starter project

## Acuan desain
UI mengikuti screenshot Kelola Keuangan Gampork: latar navy gelap, kartu slate, aksen emas, saldo hijau, pengeluaran merah, dan navigasi bawah tujuh menu.

## Implementasi yang ada
- Dashboard: saldo tercatat, total pemasukan/pengeluaran, ringkasan hari ini, grafik omzet sederhana 7 hari.
- Penjualan dan Pengeluaran: daftar transaksi, pencarian, filter kategori, tambah transaksi.
- Laporan: filter ringkas harian/mingguan/bulanan/semua, pemasukan, pengeluaran, selisih, rincian.
- Menu & Harga dan Jenis Pengeluaran: daftar awal contoh dan penambahan nama sementara.
- Pengaturan: nama usaha dan pilihan mode.
- Database lokal Room/SQLite agar pencatatan tetap berfungsi offline.

## Batasan penting
Ini starter project, belum dibuild atau diuji di Android Studio pada perangkat target. Menu & Harga dan Jenis Pengeluaran saat ini masih contoh UI; item tambahan hanya berada di memori dan belum disimpan permanen. Belum ada edit/hapus transaksi, cetak PDF, ekspor CSV, login, backup, atau sinkronisasi cloud aktif. Filter tanggal khusus dan status transaksi pada screenshot juga belum dibuat lengkap. Laporan masih agregat dasar, bukan laporan laba-rugi akuntansi final.

## Build APK
1. Ekstrak ZIP dan buka folder ini di Android Studio.
2. Gunakan JDK 17 dan Android SDK 35; tunggu Gradle Sync.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Untuk rilis, pilih Build > Generate Signed Bundle / APK > APK dan buat keystore dengan aman.

Sinkronisasi online memerlukan backend (mis. Firebase Authentication + Cloud Firestore), aturan keamanan, antrean sinkronisasi, dan pengujian konflik. Izin INTERNET saja tidak membuat sinkronisasi aktif.
